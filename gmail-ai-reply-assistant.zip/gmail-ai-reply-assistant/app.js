const messages = [
  {name:"Priya Sharma",email:"priya@example.com",date:"TODAY · 10:42 AM",subject:"Project proposal feedback",body:"Hi! I reviewed the proposal and have a few suggestions. Could you send me the updated timeline by Thursday? It would help us finalize the next steps for the project.",summary:"Priya reviewed the project proposal and is asking for an updated timeline by Thursday so the team can finalize next steps.",intent:"Share the updated project timeline.",draft:"Hi Priya,\n\nThanks for reviewing the proposal. I'll update the project timeline and share it with you by Thursday.\n\nBest,\nLakshmikanth"},
  {name:"Alex Morgan",email:"alex@example.com",date:"YESTERDAY",subject:"Meeting follow-up",body:"Thanks for taking the time to meet yesterday. Could you share the notes and the next steps when you have a chance? It would be helpful to keep everyone aligned.",summary:"Alex is following up after a meeting and would like the notes and next steps.",intent:"Share meeting notes and next steps.",draft:"Hi Alex,\n\nThanks for following up. I'll organize the meeting notes and send over the next steps shortly.\n\nBest,\nLakshmikanth"},
  {name:"Campus Innovation Team",email:"team@example.com",date:"MONDAY",subject:"Demo day confirmation",body:"We're finalizing the Demo Day schedule. Please let us know whether your team will attend and whether you need a presentation slot.",summary:"The Campus Innovation Team needs confirmation of attendance and whether a presentation slot is required.",intent:"Confirm attendance and presentation needs.",draft:"Hello,\n\nThank you for the update. I'll confirm our team's availability and whether we need a presentation slot.\n\nRegards,\nLakshmikanth"}
];
let reviewed = 0;
const $ = id => document.getElementById(id);
let activeIndex = 0;
function selectMessage(index) {
  activeIndex = index;
  const m = messages[index];
  document.querySelectorAll('.email-item').forEach((el, i) => el.classList.toggle('selected', i === index));
  $('threadDate').textContent = m.date;
  $('subject').textContent = m.subject;
  $('sender').textContent = m.name;
  $('senderEmail').textContent = m.email;
  $('senderInitial').textContent = m.name[0];
  $('messageBody').textContent = m.body;
  $('summary').textContent = m.summary;
  $('intent').textContent = m.intent;
  $('draft').value = m.draft;
  $('approve').textContent = '✓ Mark reviewed';
}
document.querySelectorAll('.email-item').forEach(el => el.addEventListener('click', () => selectMessage(Number(el.dataset.id))));
$('approve').addEventListener('click', () => {
  reviewed++;
  $('draftCount').textContent = reviewed + 1;
  $('draftStat').innerHTML = `${reviewed + 1} <small>drafts</small>`;
  $('approve').textContent = '✓ Reviewed in demo';
});
$('discard').addEventListener('click', () => {
  $('draft').value = '';
  $('approve').textContent = 'Draft discarded in demo';
});
