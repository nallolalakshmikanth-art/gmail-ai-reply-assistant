# Gmail AI Reply Assistant

A privacy-first starter project for reviewing email threads and preparing reply drafts for user approval.

## Current status

This repository package is a **frontend demo** with fictional sample inbox data. It does not yet connect to a real Gmail account, read messages, call an AI model, or save drafts to Gmail. Those features require Google OAuth, Gmail API configuration, and a secure backend.

## Features in this starter

- Inbox-style view of messages that may need a reply
- Thread summary and context panel
- Editable suggested reply
- Local demo interactions to mark a draft reviewed or discard it
- Responsive desktop and mobile layout
- Clear notice that no email is sent automatically

## Run locally

No build step is required.

1. Download or clone this repository.
2. Open `index.html` in a browser.

Alternatively, run a local static server from the project directory:

```bash
python -m http.server 5500
```

Then visit <http://localhost:5500>.

## Deploy

Import the repository into Vercel or Netlify as a static site, or enable GitHub Pages from the repository's **Settings → Pages** and select the `main` branch and `/ (root)` folder.

## Roadmap for a real Gmail integration

1. Create a Google Cloud project and enable the Gmail API.
2. Configure OAuth consent and authorized redirect URIs.
3. Build a backend to handle OAuth and store tokens securely server-side.
4. Request the minimum Gmail scopes needed. Start with read-only access; request draft-creation access only when implementing saved drafts.
5. Fetch threads and identify response-needed messages.
6. Generate suggested text using an AI model and display the thread context beside it.
7. Save drafts only after review; never send automatically.
8. Add tests, token revocation, secure secret management, and robust error handling.

## Security

Never put Google client secrets, refresh tokens, or API keys in frontend code or commit them to this repository. Do not use this demo with real email data until authentication, authorization, and data handling have been implemented and reviewed.
